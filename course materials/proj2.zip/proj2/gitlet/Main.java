package gitlet;
import java.io.File;
/** Driver class for Gitlet, a subset of the Git version-control system.
 *  @author TODO
 */
public class Main {

    /** Usage: java gitlet.Main ARGS, where ARGS contains
     *  <COMMAND> <OPERAND1> <OPERAND2> ... 
     */
    public static void main(String[] args) {
        // TODO: what if args is empty?

        if (args.length == 0) {
            System.out.println("Please enter a command.");
            System.exit(0);
        }


        Repository repo = new Repository();
        if(Repository.REPO_FILE.exists()) {
            repo = Utils.readObject(Repository.REPO_FILE, Repository.class);
        }
        
        String firstArg = args[0];
        switch(firstArg) {
            case "init":
                // TODO: handle the `init` command
                validateNumArgs(firstArg, args, 1);
                repo.init();
                break;
            case "add":
                validateNumArgs(firstArg, args, 2);
                // TODO: handle the `add [filename]` command
                repo.add(args[1]);
                break;

            // TODO: FILL THE REST IN
            case "commit":
                validateNumArgs(firstArg, args, 2);
                String message = args[1];
                if (message.equals("")) {
                    throw new GitletException("Please enter a commit message.");
                }
                repo.commit(message);
                break;

            case "rm":
                validateNumArgs(firstArg, args, 2);
                String fileName= args[1];
                if (fileName.equals("")) {
                    throw new GitletException("Please enter a file name.");
                }
                repo.commit(fileName);
                break;

            case "checkout":
                repo.checkOut(args);
                break;



            default:
                errorMessage(1);
                System.exit(0);
        }
    }


    private static void errorMessage(int n){
        switch(n){
            case 1:
                throw new gitlet.GitletException("No command with that name exists");
            case 2:
                throw new gitlet.GitletException("Incorrect operands.");


        }
    }
    private static void validateNumArgs(String cmd, String[] args, int n){
        if(args.length!=n){
            System.out.println("Invalid number of arguments");
        }
        switch(args.length){
            case 2:
                return;
            case 3:
                errorMessage(2);
        }
    }
}
