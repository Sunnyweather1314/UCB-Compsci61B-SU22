package gitlet;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import static gitlet.Utils.*;


// TODO: any imports you need here

/** Represents a gitlet repository.
 *  TODO: It's a good idea to give a description here of what else this Class
 *  does at a high level.
 *
 *  @author TODO
 */
public class Repository implements Serializable{
    /**
     * TODO: add instance variables here.
     *
     * List all instance variables of the Repository class here with a useful
     * comment above them describing what that variable represents and how that
     * variable is used. We've provided two examples for you.
     */

    /** The current working directory. */
    public static final File CWD = new File(System.getProperty("user.dir"));
    /** The .gitlet directory. */
    public static final File GITLET_DIR = Utils.join(CWD, ".gitlet");
    /** The head pointer of the CWD, kept in .gitlet folder*/
    public static final File Head = Utils.join(GITLET_DIR, "Head.txt");

    /** The commit directory, commit instances will be written inside this directory. */
    public static final File COMMIT_DIR = Utils.join(GITLET_DIR, "Commits");
    /** The blobs that has been added or commited*/
    public static final File BLOB_DIR = Utils.join(GITLET_DIR, "Blobs");
    public static final File BRANCH_DIR = Utils.join(GITLET_DIR, "Branches");
    public static final File REPO_FILE = Utils.join(GITLET_DIR, "repo.txt");
    public HashMap<String, File> stage;
    public File headCommit;
    public Branch main;


    public Repository(){


    }


    /* TODO: fill in the rest of this class. */
    public void init(){
        if(GITLET_DIR.exists()){
            throw new GitletException("A Gitlet version-control system already exists in the current directory.");
        }

        if (!REPO_FILE.exists()){
            

            GITLET_DIR.mkdir();
            COMMIT_DIR.mkdir();
            BLOB_DIR.mkdir();
            stage = new HashMap<String, File>();
            save(this);
            this.commit("initial commit");
            main = new Branch("main",Utils.readObject(headCommit, Commit.class).sha1Code());


        }

        // save(this);


    }

    public void add(String file){
        File fileRef = Utils.join(CWD, file);
        checkExistence(fileRef);
        Repository repo = Utils.readObject(REPO_FILE, Repository.class);
        Blob blob = new Blob(fileRef, file);
        blob.save();
        repo.stage.put(blob.getName(), blob.getFileRef());
        repo.save(repo);
    }


    public void commit(String message){
        Repository repo = Utils.readObject(REPO_FILE, Repository.class);
        if(repo.stage == null){
            throw new GitletException("No changes added to the commit.");
        }
        
        Commit commited = new Commit(message, headCommit, repo.stage, main);
        repo.stage = new HashMap<String, File>();
        headCommit = commited.getFileRef();
        repo.save(repo);

    }


    public void remove(String filename){
        Repository repo = Utils.readObject(REPO_FILE, Repository.class);
        File fileRef = Utils.join(CWD, filename);
        checkExistence(fileRef);


        boolean contained = false;
        if (repo.stage.containsKey(filename)) {
            repo.stage.remove(filename);
            contained = true;
        }

        Commit head = Utils.readObject(repo.headCommit, Commit.class);
        if (head.getBlobs().containsKey(filename)) {
            add(filename);
            Utils.restrictedDelete(filename);
            // s.removeFile(filename);
            contained = true;
        }
        if (!contained) {
            throw new GitletException("No reason to remove the file.");
        }
        repo.save(repo);

    }


    public void checkOut(String... args) {

        Repository repo = Utils.readObject(REPO_FILE, Repository.class);
        Commit head = Utils.readObject(repo.headCommit, Commit.class);
        if (args.length == 2) {
            // checkOutAll(args[1]);
        } else if (args.length == 3) {
            checkOutOne(head, args[2]);
        } else {
            Commit t = head;

            while(t != null) {

                if(t.sha1Code().equals(args[1])){
                    checkOutOne(t, args[3]);
                }
                File temp = head.getParent();

                t = Utils.readObject(temp, Commit.class);
            }
            
            throw new GitletException("No commit with that id exists.");
        }

        repo.save(repo);
    }


    private void checkOutOne(Commit commit, String file) {
        Repository repo = Utils.readObject(REPO_FILE, Repository.class);

        if(commit.getBlobs().containsKey(file)){

        }else{
            throw new GitletException("File does not exist in that commit.");
        }



        Blob blob = Utils.readObject((File) commit.getBlobs().get(file), Blob.class);
        File blobPath = blob.getFileRef();
        byte[] contents =  Utils.readContents(blobPath);
        File filePath = Utils.join(CWD, file);
        Utils.writeContents(filePath, contents);


    }

//     public void checkout(String filename){

//     }
// checkout [commit id] -- [file name]
// log



    private static void checkExistence(File fileRef) {
        if (!GITLET_DIR.exists()) {
            throw new GitletException(
                    "Not in an initialized Gitlet directory.");
        }

        if (!fileRef.exists()) {
            throw new GitletException(
                    "File does not exist.");
        }
    }

    public void save(Repository repo){
        Utils.writeObject(REPO_FILE, repo);
    }
}
