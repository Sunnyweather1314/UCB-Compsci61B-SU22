package gitlet;

import java.io.File;
import java.io.Serializable;

public class Branch implements Serializable {

    /**The name of the branch.*/
    private String name;
    /**The latest commit this branch heads to.*/
    private String commit;


    public Branch(String name, String commit) {
        this.name = name;
        this.commit = commit;
    }

    public String getName() {return name;}

    public String getCommit() {return commit;}


    public void saveBranch() {
        File branch = Utils.join(Repository.BRANCH_DIR,
                Utils.sha1(name) + ".txt");
        Utils.writeObject(branch, this);

    }

    public void update(String sha1) {
        commit = sha1; }

}

