package byow.Core;

import byow.InputDemo.InputSource;
import byow.InputDemo.KeyboardInputSource;
import byow.InputDemo.StringInputDevice;
import byow.TileEngine.TERenderer;
import byow.TileEngine.TETile;
import byow.TileEngine.Tileset;
import edu.princeton.cs.algs4.StdDraw;

import java.awt.*;
import java.io.File;
import java.util.*;
import java.util.List;

import static byow.Core.Utils.*;

public class Engine {
    TERenderer ter = new TERenderer();
    /* Feel free to change the width and height. */
    public static final int WIDTH = 80;
    public static final int HEIGHT = 46;
    public static final int NORTH = 0;
    public static final int EAST = 1;
    public static final int SOUTH = 2;
    public static final int WEST = 3;
    private static final File SAVINGPATH = join(System.getProperty("user.dir"), "saved.txt");
    private Random rand;
    private List<Room> roomList = new ArrayList<>();
    private Queue<Door> doorQueue = new ArrayDeque<>();
    private List<Door> usedDoorList = new ArrayList<>();
    private List<LightBulb> lightBulbList = new ArrayList<>();
    private List<Connection> connectionList = new ArrayList<>();
    private TETile[][] myWorld;
    private TETile[][] duplicateWorld;
    private TETile[][] lightOnWorld;
    private Avatar avatar;

    private String gameKey = "";
    private int mousePosX = 500;
    private int mousePosY = 500;
    private String currTileName = "";
    private boolean lightOn = false;
    private boolean visionOff = false;

    /**
     * Method used for exploring a fresh world. This method should handle all inputs,
     * including inputs from the main menu.
     */
    public void interactWithKeyboard() {
        ter.initialize(WIDTH, HEIGHT);
        ter.initializeMenu();
        InputSource inputDevice = new KeyboardInputSource();
        while (inputDevice.possibleNextInput()) {
            char c = inputDevice.getNextKey();
            if (c == 'L') {
                String previousKey = readContentsAsString(SAVINGPATH);
                myWorld = interactWithInputString(previousKey);
                gameKey = previousKey;
                ter.initialize(WIDTH, HEIGHT);
                drawWorld();
                break;
            }
            if (c == 'N') {
                ter.menuWithSeed("");
                long seed = getSeed(inputDevice);
                rand = new Random(seed);
                generateWorld(rand);
                ter.initialize(WIDTH, HEIGHT);
                drawWorld();
                break;
            }
            if (c == 'Q') {
                ter.quittingScreen();
                break;
            }
        }
        operateAvatar(inputDevice, true);
    }

    private long getSeed(InputSource i) {
        String seed = "";
        gameKey = "N";
        while (i.possibleNextInput()) {
            char c = i.getNextKey();
            if (Character.isDigit(c)) {
                seed += c;
                gameKey += c;
                ter.menuWithSeed(seed);
            } else if (!seed.equals("") && c == 'S') {
                gameKey += "S";
                break;
            }
        }
        return Long.parseLong(seed);
    }

    private void operateAvatar(InputSource i, boolean isKeyboard) {
        while (i.possibleNextInput()) {
            while (isKeyboard && !StdDraw.hasNextKeyTyped()) {
                currTileName = getTilePropertyWithMouse();
                drawWorld();
            }
            int x = avatar.getX();
            int y = avatar.getY();
            char c = i.getNextKey();
            if ((c == 'W' || c == 'w') && getTile(x, y + 1) == Tileset.FLOOR) {
                gameKey += c;
                myWorld[x][y] = Tileset.FLOOR;
                myWorld[x][y + 1] = Tileset.AVATAR;
                avatar = new Avatar(x, y + 1);
                if (isKeyboard) {
                    drawWorld();
                }
            } else if ((c == 'D' || c == 'd') && getTile(x + 1, y) == Tileset.FLOOR) {
                gameKey += c;
                myWorld[x][y] = Tileset.FLOOR;
                myWorld[x + 1][y] = Tileset.AVATAR;
                avatar = new Avatar(x + 1, y);
                if (isKeyboard) {
                    drawWorld();
                }
            } else if ((c == 'S' || c == 's') && getTile(x, y - 1) == Tileset.FLOOR) {
                gameKey += c;
                myWorld[x][y] = Tileset.FLOOR;
                myWorld[x][y - 1] = Tileset.AVATAR;
                avatar = new Avatar(x, y - 1);
                if (isKeyboard) {
                    drawWorld();
                }
            } else if ((c == 'A' || c == 'a') && getTile(x - 1, y) == Tileset.FLOOR) {
                gameKey += c;
                myWorld[x][y] = Tileset.FLOOR;
                myWorld[x - 1][y] = Tileset.AVATAR;
                avatar = new Avatar(x - 1, y);
                if (isKeyboard) {
                    drawWorld();
                }
            } else if (c == 'J') {
                gameKey += c;
                lightOn = !lightOn;
                if (isKeyboard) {
                    drawWorld();
                }
            } else if (c == 'K') {
                gameKey += c;
                visionOff = !visionOff;
                if (isKeyboard) {
                    drawWorld();
                }
            } else if (c == ':') {
                char nextC = i.getNextKey();
                if (nextC == 'Q' || nextC == 'q') {
                    saveGame();
                    if (isKeyboard) {
                        ter.quittingScreen();
                    }
                    return;
                }
            }
        }

    }
    private void saveGame() {
        writeContents(SAVINGPATH, gameKey);
    }
    /**
     * Method used for autograding and testing your code. The input string will be a series
     * of characters (for example, "n123sswwdasdassadwas", "n123sss:q", "lwww". The engine should
     * behave exactly as if the user typed these characters into the engine using
     * interactWithKeyboard.
     *
     * Recall that strings ending in ":q" should cause the game to quite save. For example,
     * if we do interactWithInputString("n123sss:q"), we expect the game to run the first
     * 7 commands (n123sss) and then quit and save. If we then do
     * interactWithInputString("l"), we should be back in the exact same state.
     *
     * In other words, both of these calls:
     *   - interactWithInputString("n123sss:q")
     *   - interactWithInputString("lww")
     *
     * should yield the exact same world state as:
     *   - interactWithInputString("n123sssww")
     *
     * @param input the input string to feed to your program
     * @return the 2D TETile[][] representing the state of the world
     */
    public TETile[][] interactWithInputString(String input) {
        //
        // passed in as an argument, and return a 2D tile representation of the
        // world that would have been drawn if the same inputs had been given
        // to interactWithKeyboard().
        //
        // See proj3.byow.InputDemo for a demo of how you can make a nice clean interface
        // that works for many different input types.
        myWorld = null;
        if (input.charAt(0) == 'L' || input.charAt(0) == 'l') {
            String savedKey = readContentsAsString(SAVINGPATH);
            if (savedKey.equals("")) {
                return myWorld;
            }
            input = savedKey.concat(input.substring(1));
        }
        String seed = "0";
        int operationIndex = 0;
        for (int i = 1; i < input.length(); i++) {
            if (input.charAt(i) == 'S' || input.charAt(i) == 's') {
                seed = input.substring(1, i);
                operationIndex = i + 1;
                gameKey = input.substring(0, operationIndex);
                break;
            }
        }
        rand = new Random(Long.parseLong(seed));
        generateWorld(rand);
        InputSource i = new StringInputDevice(input.substring(operationIndex));
        operateAvatar(i, false);
//        ter.initialize(WIDTH, HEIGHT);
//        ter.renderFrame(myWorld);
        return myWorld;
    }
    private TETile[][] createEmptyWorld() {
        TETile[][] world = new TETile[WIDTH][HEIGHT];
        for (int x = 0; x < WIDTH; x += 1) {
            for (int y = 0; y < HEIGHT; y += 1) {
                world[x][y] = Tileset.NOTHING;
            }
        }
        return world;
    }
    private TETile getTile(int x, int y) {
        return myWorld[x][y];
    }

    private String getTilePropertyWithMouse() {
        mousePosX = (int) StdDraw.mouseX();
        mousePosY = (int) StdDraw.mouseY();
        if (mousePosY >= HEIGHT) {
            return "nothing";
        } else {
            if (myWorld[mousePosX][mousePosY] == Tileset.FLOOR) {
                return "floor";
            } else if (myWorld[mousePosX][mousePosY] == Tileset.WALL) {
                return "wall";
            } else if (myWorld[mousePosX][mousePosY] == Tileset.NOTHING) {
                return "nothing";
            } else if (myWorld[mousePosX][mousePosY] == Tileset.AVATAR) {
                return "avatar";
            } else {
                return "";
            }
        }
    }

    private Room generateRoom(Door d) {
        int depth;
        int side = d.getSide();
        int randomNum = rand.nextInt(5);
        if (randomNum == 0) {
            depth = 1;
        } else if (randomNum == 1) {
            depth = 2;
        } else {
            depth = rand.nextInt(3, 7);
        }
        int x1 = d.getX() - (1 - side % 2) * (rand.nextInt(4) + 1) - (side / 3) * (depth + 1);
        int y1 = d.getY() - (side % 2) * (rand.nextInt(4) + 1)
                - (2 * ((side + 1) / 3) + ((side + 2) / 3) - side) * (depth + 1);
        int x2 = d.getX() + (1 - side % 2) * (rand.nextInt(4) + 1)
                + (2 * ((side + 2) / 3) + (side / 3) - side) * (depth + 1);
        int y2 = d.getY() + (side % 2) * (rand.nextInt(4) + 1) + ((3 - side) / 3) * (depth + 1);
        Room newRoom = new Room(x1, y1, x2, y2);
        return newRoom;
    }
    private void generateDoor(Room r) {
        Door northDoor = new Door(rand.nextInt(r.bottomLeftX() + 1, r.topRightX()),
                r.topRightY(), NORTH, r);
        Door eastDoor = new Door(r.topRightX(), rand.nextInt(r.bottomLeftY() + 1,
                r.topRightY()), EAST, r);
        Door southDoor = new Door(rand.nextInt(r.bottomLeftX() + 1, r.topRightX()),
                r.bottomLeftY(), SOUTH, r);
        Door westDoor = new Door(r.bottomLeftX(), rand.nextInt(r.bottomLeftY() + 1,
                r.topRightY()), WEST, r);
        doorQueue.add(northDoor);
        doorQueue.add(eastDoor);
        doorQueue.add(southDoor);
        doorQueue.add(westDoor);
    }
    private void generateWorld(Random r) {
        myWorld = createEmptyWorld();
        int initX1 = r.nextInt(10, WIDTH - 17);
        int initY1 = r.nextInt(10, HEIGHT - 17);
        Room firstRoom = new Room(initX1, initY1, initX1 + r.nextInt(3, 8),
                initY1 + r.nextInt(3, 8));
        roomList.add(firstRoom);
        generateDoor(firstRoom);
        while (!doorQueue.isEmpty()) {
            Door currentDoor = doorQueue.poll();
            Room newRoom = generateRoom(currentDoor);
            boolean willUse = true;
            for (Room existedRoom : roomList) {
                if (newRoom.roomOutOfBound() || newRoom.roomConflict(existedRoom)) {
                    willUse = false;
                    break;
                }
            }
            if (willUse) {
                roomList.add(newRoom);
                usedDoorList.add(currentDoor);
                generateDoor(newRoom);
                Connection currConnection = new Connection(currentDoor, newRoom);
                connectionList.add(currConnection);
            }
        }
        for (Room existedRoom : roomList) {
            int x1 = existedRoom.bottomLeftX();
            int y1 = existedRoom.bottomLeftY();
            int x2 = existedRoom.topRightX();
            int y2 = existedRoom.topRightY();
            for (int i = x1; i <= x2; i++) {
                for (int j = y1; j <= y2; j++) {
                    myWorld[i][j] = Tileset.WALL;
                }
            }
            for (int i = x1 + 1; i < x2; i++) {
                for (int j = y1 + 1; j < y2; j++) {
                    myWorld[i][j] = Tileset.FLOOR;
                }
            }
            for (Door d : usedDoorList) {
                myWorld[d.getX()][d.getY()] = Tileset.FLOOR;
            }
        }
        getLightRoom();
        generateInitAvatar();
        myWorld[avatar.getX()][avatar.getY()] = Tileset.AVATAR;

    }
    public void getLightRoom() {
        List<Room> tempRoomList = new ArrayList<>();
        for (Room r : roomList) {
            tempRoomList.add(r);
        }
        int count = 0;
        int total = tempRoomList.size();
        int randomNum = rand.nextInt(1, total);
        while (count < randomNum) {
            Room currRoom = tempRoomList.remove(rand.nextInt(0, total));
            int currX1 = currRoom.bottomLeftX();
            int currY1 = currRoom.bottomLeftY();
            int currX2 = currRoom.topRightX();
            int currY2 = currRoom.topRightY();
            int lightBulbX = rand.nextInt(currX1 + 1, currX2);
            int lightBulbY = rand.nextInt(currY1 + 1, currY2);
            LightBulb currLightBulb = new LightBulb(lightBulbX, lightBulbY, currRoom);
            lightBulbList.add(currLightBulb);
            count++;
            total--;
        }
    }
    public void createDuplicateWorld() {
        duplicateWorld  = new TETile[WIDTH][HEIGHT];
        for (int i = 0; i < WIDTH; i++) {
            for (int j = 0; j < HEIGHT; j++) {
                duplicateWorld[i][j] = myWorld[i][j];
            }
        }
    }
    public void createLightOnWorld() {
        lightOnWorld = new TETile[WIDTH][HEIGHT];
        for (int i = 0; i < WIDTH; i++) {
            for (int j = 0; j < HEIGHT; j++) {
                lightOnWorld[i][j] = myWorld[i][j];
            }
        }
        for (LightBulb l : lightBulbList) {
            for (int i = l.getRoom().bottomLeftX() + 1; i < l.getRoom().topRightX(); i++) {
                for (int j = l.getRoom().bottomLeftY() + 1; j < l.getRoom().topRightY(); j++) {
                    int dx = Math.abs(i - l.getX());
                    int dy = Math.abs(j - l.getY());
                    double index = Math.sqrt(dx * dx + dy * dy) + 1;
                    lightOnWorld[i][j] = new TETile('·', new Color(128, 192, 128),
                            new Color((int) (255 / index), 0, (int) (255 / index)), "floor");
                }
            }
        }
        lightOnWorld[avatar.getX()][avatar.getY()] = new TETile('@',
                Color.blue, Color.black, "you");
    }

    private void coverWorld(TETile[][] world) {
        List<Room> tempRoomList = new ArrayList<>();
        List<Room> usedRoomList = new ArrayList<>();
        List<Door> tempDoorList = new ArrayList<>();
        List<Connection> tempConnectionList = new ArrayList<>();
        tempConnectionList.addAll(connectionList);
        tempRoomList.addAll(roomList);
        int currX = avatar.getX();
        int currY = avatar.getY();
        boolean onDoor = false;
        for (Connection c : connectionList) {
            if (c.getDoor().getX() == currX && c.getDoor().getY() == currY) {
                usedRoomList.add(c.getDoor().getRoom());
                usedRoomList.add(c.getNextRoom());
                tempDoorList.add(c.getDoor());
                onDoor = true;
                break;
            }
        }
        if (!onDoor) {
            for (Room r : roomList) {
                if (r.bottomLeftX() < currX && r.bottomLeftY() < currY && r.topRightX() > currX
                        && r.topRightY() > currY) {
                    usedRoomList.add(r);
                    break;
                }
            }
        }
        while (true) {
            int count = 0;
            for (Connection c : tempConnectionList) {
                int doorX = c.getDoor().getX();
                int doorY = c.getDoor().getY();
                if (Math.abs(doorX - currX) < 6 && Math.abs(doorY - currY) < 6) {
                    if (usedRoomList.contains(c.getDoor().getRoom())) {
                        if (!usedRoomList.contains(c.getNextRoom())) {
                            usedRoomList.add(c.getNextRoom());
                            tempDoorList.add(c.getDoor());
                            count += 1;
                        }
                    }
                    if (usedRoomList.contains(c.getNextRoom())) {
                        if (!usedRoomList.contains(c.getDoor().getRoom())) {
                            usedRoomList.add(c.getDoor().getRoom());
                            tempDoorList.add(c.getDoor());
                            count += 1;
                        }
                    }
                }
            }
            if (count == 0) {
                break;
            }
        }
        for (Room r : usedRoomList) {
            tempRoomList.remove(r);
        }
        fillWithDark(world, currX, currY);
        destroyGarbageRoom(world, tempRoomList);
        repairDestroyedWall(world, usedRoomList);
        for (Door d : tempDoorList) {
            world[d.getX()][d.getY()] = Tileset.FLOOR;
        }
        if (lightOn) {
            world[avatar.getX()][avatar.getY()] = new TETile('@', Color.blue, Color.black, "you");
        } else {
            world[avatar.getX()][avatar.getY()] = Tileset.AVATAR;
        }
        fillWithDark(world, currX, currY);
    }
    private void fillWithDark(TETile[][] world, int xPos, int yPos) {
        for (int i = 0; i < WIDTH; i++) {
            for (int j = 0; j < HEIGHT; j++) {
                if (Math.abs(xPos - i) > 5 || Math.abs(yPos - j) > 5) {
                    world[i][j] = Tileset.NOTHING;
                }
            }
        }
    }
    private void destroyGarbageRoom(TETile[][] world, List<Room> l) {
        for (Room r : l) {
            for (int i = r.bottomLeftX(); i <= r.topRightX(); i++) {
                for (int j = r.bottomLeftY(); j <= r.topRightY(); j++) {
                    world[i][j] = Tileset.NOTHING;
                }
            }
        }
    }
    private void repairDestroyedWall(TETile[][] world, List<Room> l) {
        for (Room r : l) {
            for (int i = r.bottomLeftX(); i <= r.topRightX(); i++) {
                for (int j = r.bottomLeftY(); j <= r.topRightY(); j++) {
                    if (i == r.bottomLeftX() || i == r.topRightX()
                            || j == r.bottomLeftY() || j == r.topRightY()) {
                        world[i][j] = Tileset.WALL;
                    }
                }
            }
        }
    }
    private void generateInitAvatar() {
        int xPos = rand.nextInt(0, WIDTH);
        int yPos = rand.nextInt(0, HEIGHT);
        if (myWorld[xPos][yPos] == Tileset.FLOOR) {
            avatar = new Avatar(xPos, yPos);
        } else {
            generateInitAvatar();
        }
    }
    private void drawWorld() {
        if (lightOn) {
            createLightOnWorld();
            if (visionOff) {
                coverWorld(lightOnWorld);
            }
            ter.renderFrame(lightOnWorld, currTileName);
        } else {
            createDuplicateWorld();
            if (visionOff) {
                coverWorld(duplicateWorld);
            }
            ter.renderFrame(duplicateWorld, currTileName);
        }
    }
    public static void main(String[] args) {
        Engine engine = new Engine();
        engine.interactWithInputString(args[0]);
    }
}

