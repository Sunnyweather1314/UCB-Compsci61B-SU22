package byow.Core;

public class Connection {
    private Door door;
    private Room nextRoom;

    public Connection(Door d, Room r) {
        door = d;
        nextRoom = r;
    }

    public Door getDoor() {
        return door;
    }

    public Room getNextRoom() {
        return nextRoom;
    }
}
