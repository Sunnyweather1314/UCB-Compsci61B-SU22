package byow.Core;

public class LightBulb {
    private int xPos;
    private int yPos;
    private Room room;

    public LightBulb(int x, int y, Room r) {
        xPos = x;
        yPos = y;
        room = r;
    }

    public int getX() {
        return xPos;
    }

    public int getY() {
        return yPos;
    }

    public Room getRoom() {
        return room;
    }
}
