package byow.Core;

public class Door {
    private int x;
    private int y;
    private int side;
    private Room room;


    public Door(int x, int y, int side, Room room) {
        this.x = x;
        this.y = y;
        this.side = side;
        this.room = room;
    }

    public int getX() {
        return this.x;
    }
    public int getY() {
        return this.y;
    }
    public int getSide() {
        return this.side;
    }

    public Room getRoom() {
        return this.room;
    }

}

