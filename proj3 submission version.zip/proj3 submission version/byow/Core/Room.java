package byow.Core;

public class Room {
    private int bottomLeftX;
    private int bottomLeftY;
    private int topRightX;
    private int topRightY;

    public Room(int x1, int y1, int x2, int y2) {
        bottomLeftX = x1;
        bottomLeftY = y1;
        topRightX = x2;
        topRightY = y2;
    }

    public boolean roomConflict(Room r) {
        return this.bottomLeftX() < r.topRightX() && this.topRightX() > r.bottomLeftX()
                && this.bottomLeftY() < r.topRightY() && this.topRightY() > r.bottomLeftY();
    }
    public boolean roomOutOfBound() {
        return !(this.bottomLeftX() >= 0 && this.bottomLeftY() >= 0
                && this.topRightX() < Engine.WIDTH && this.topRightY() < Engine.HEIGHT - 2);
    }
    public int bottomLeftX() {
        return bottomLeftX;
    }
    public int bottomLeftY() {
        return bottomLeftY;
    }
    public int topRightX() {
        return topRightX;
    }
    public int topRightY() {
        return topRightY;
    }
}

